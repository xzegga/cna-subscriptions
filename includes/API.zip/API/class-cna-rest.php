<?php
/**
 * Controlador REST API
 * Endpoints para el frontend React y webhooks de Pagadito
 *
 * @package CNA_Subscriptions
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class CNA_REST_Controller {

    /**
     * Namespace de la API
     */
    const NAMESPACE = 'cna/v1';

    /**
     * Inicializa los endpoints
     */
    public function init() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    /**
     * Registra las rutas REST
     */
    public function register_routes() {
        // GET /shipping-rate
        register_rest_route(self::NAMESPACE, '/shipping-rate', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_shipping_rate'),
            'permission_callback' => '__return_true', // Público para el checkout
            'args' => array(
                'product_id' => array(
                    'required' => true,
                    'type' => 'integer',
                    'validate_callback' => function($param) {
                        return is_numeric($param) && $param > 0;
                    },
                ),
                'district' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'country' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default' => 'El Salvador',
                ),
                'department' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'municipality' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));

        // GET /shipping-options (retorna home + pickup)
        register_rest_route(self::NAMESPACE, '/shipping-options', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_shipping_options'),
            'permission_callback' => '__return_true',
            'args' => array(
                'product_id' => array(
                    'required' => true,
                    'type' => 'integer',
                    'validate_callback' => function($param) {
                        return is_numeric($param) && $param > 0;
                    },
                ),
                'district' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'country' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default' => 'El Salvador',
                ),
                'department' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'municipality' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ));

        // GET /pickup-stores
        register_rest_route(self::NAMESPACE, '/pickup-stores', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_pickup_stores'),
            'permission_callback' => '__return_true',
        ));

        // POST /create-order
        register_rest_route(self::NAMESPACE, '/create-order', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_order'),
            'permission_callback' => array($this, 'check_rate_limit'), // Rate limiting básico
        ));

        // GET /payment-return (Return URL de Pagadito)
        register_rest_route(self::NAMESPACE, '/payment-return', array(
            'methods' => 'GET',
            'callback' => array($this, 'handle_payment_return'),
            'permission_callback' => '__return_true', // Público, validación interna
        ));

        // POST /webhook/pagadito
        register_rest_route(self::NAMESPACE, '/webhook/pagadito', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_pagadito_webhook'),
            'permission_callback' => '__return_true', // Público, validación interna
            // Nota: La validación de origen del webhook debe implementarse según
            // la documentación específica de Pagadito (firma, IP whitelist, etc.)
        ));

        // GET /user/subscriptions
        register_rest_route(self::NAMESPACE, '/user/subscriptions', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_user_subscriptions'),
            'permission_callback' => array($this, 'check_user_permission'),
        ));

        // GET /subscriptions/(?P<id>\d+)/deliveries
        register_rest_route(self::NAMESPACE, '/subscriptions/(?P<id>\d+)/deliveries', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_subscription_deliveries'),
            'permission_callback' => array($this, 'check_user_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'integer',
                    'validate_callback' => function($param) {
                        return is_numeric($param) && $param > 0;
                    },
                ),
            ),
        ));

        // POST /subscriptions/(?P<id>\d+)/toggle-renew
        register_rest_route(self::NAMESPACE, '/subscriptions/(?P<id>\d+)/toggle-renew', array(
            'methods' => 'POST',
            'callback' => array($this, 'toggle_subscription_renewal'),
            'permission_callback' => array($this, 'check_user_permission'),
            'args' => array(
                'id' => array(
                    'required' => true,
                    'type' => 'integer',
                    'validate_callback' => function($param) {
                        return is_numeric($param) && $param > 0;
                    },
                ),
            ),
        ));

        // GET /locations
        register_rest_route(self::NAMESPACE, '/locations', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_locations_data'),
            'permission_callback' => '__return_true', // Público
        ));

        // POST /register
        register_rest_route(self::NAMESPACE, '/register', array(
            'methods' => 'POST',
            'callback' => array($this, 'register_user'),
            'permission_callback' => '__return_true', // Público, validación interna
        ));

        // POST /login
        register_rest_route(self::NAMESPACE, '/login', array(
            'methods' => 'POST',
            'callback' => array($this, 'login_user'),
            'permission_callback' => '__return_true', // Público, validación interna
        ));
    }

    /**
     * Endpoint: GET /shipping-rate
     * Calcula el precio de envío para un producto en un distrito específico
     */
    public function get_shipping_rate($request) {
        $product_id = $request->get_param('product_id');
        $district = $request->get_param('district');
        $department = $request->get_param('department');
        $municipality = $request->get_param('municipality');

        // Buscar la zona del distrito
        $locations_helper = new CNA_Locations_Helper();
        $country = $request->get_param('country') ?: 'El Salvador';
        $zone_id = $locations_helper->find_zone_by_location($department, $municipality, $district, $country);

        if (!$zone_id) {
            return new WP_Error(
                'no_coverage',
                __('No hay cobertura de envío para esta ubicación', 'cna-subscriptions'),
                array('status' => 404)
            );
        }

        // Obtener precio de envío del producto para esta zona
        $shipping_prices = get_post_meta($product_id, '_cna_shipping_prices', true);
        
        if (!is_array($shipping_prices) || !isset($shipping_prices[$zone_id])) {
            return new WP_Error(
                'no_shipping_price',
                __('No hay precio de envío configurado para esta zona', 'cna-subscriptions'),
                array('status' => 404)
            );
        }

        // Obtener nombre de la zona
        global $wpdb;
        $table_prefix = $wpdb->prefix;
        $zone_name = $wpdb->get_var($wpdb->prepare(
            "SELECT name FROM {$table_prefix}cna_shipping_zones WHERE id = %d",
            $zone_id
        ));

        return rest_ensure_response(array(
            'price' => floatval($shipping_prices[$zone_id]),
            'zone_id' => $zone_id,
            'zone_name' => $zone_name,
        ));
    }

    /**
     * Endpoint: GET /shipping-options
     * Retorna todas las opciones de envío disponibles (home + pickup)
     */
    public function get_shipping_options($request) {
        $product_id = $request->get_param('product_id');
        $district = $request->get_param('district');
        $department = $request->get_param('department');
        $municipality = $request->get_param('municipality');
        $country = $request->get_param('country') ?: 'El Salvador';

        $options = array();

        // Opción 1: Envío a domicilio (si hay zona configurada)
        if ($district && $department && $municipality) {
            $locations_helper = new CNA_Locations_Helper();
            $zone_id = $locations_helper->find_zone_by_location($department, $municipality, $district, $country);

            if ($zone_id) {
                $shipping_prices = get_post_meta($product_id, '_cna_shipping_prices', true);
                
                if (is_array($shipping_prices) && isset($shipping_prices[$zone_id])) {
                    $options[] = array(
                        'type' => 'home',
                        'label' => __('Envío a domicilio', 'cna-subscriptions'),
                        'cost' => floatval($shipping_prices[$zone_id]),
                        'zone_id' => $zone_id,
                    );
                }
            }
        }

        // Opción 2: Recoger en tienda (siempre disponible)
        $options[] = array(
            'type' => 'pickup',
            'label' => __('Recoger en tienda', 'cna-subscriptions'),
            'cost' => 0.00,
        );

        return rest_ensure_response(array(
            'options' => $options,
        ));
    }

    /**
     * Endpoint: GET /pickup-stores
     * Retorna todas las tiendas de recogida activas
     */
    public function get_pickup_stores($request) {
        global $wpdb;
        $table_prefix = $wpdb->prefix;

        // Usar prepare aunque la query sea estática (mejores prácticas de seguridad)
        $stores = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, name, address, department, municipality, district, phone, hours 
                 FROM {$table_prefix}cna_pickup_stores 
                 WHERE is_active = %d 
                 ORDER BY name ASC",
                1
            )
        );

        $stores_data = array();
        foreach ($stores as $store) {
            $stores_data[] = array(
                'id' => intval($store->id),
                'name' => sanitize_text_field($store->name),
                'address' => sanitize_text_field($store->address),
                'department' => sanitize_text_field($store->department),
                'municipality' => sanitize_text_field($store->municipality),
                'district' => sanitize_text_field($store->district),
                'phone' => sanitize_text_field($store->phone),
                'hours' => $store->hours, // JSON, se mantiene como está pero se valida en frontend
            );
        }

        return rest_ensure_response(array(
            'stores' => $stores_data,
        ));
    }

    /**
     * Endpoint: POST /create-order
     * Crea una suscripción y genera URL de pago en Pagadito
     */
    public function create_order($request) {
        // Log inicial de la petición
        error_log('CNA create_order: Iniciando creación de orden');
        error_log('CNA create_order: Request data: ' . print_r($request->get_json_params(), true));
        
        $data = $request->get_json_params();

        // Validar datos requeridos
        $required = array('product_id', 'user_id', 'variant', 'shipping');
        foreach ($required as $field) {
            if (empty($data[$field])) {
                $error_msg = sprintf('Campo requerido faltante: %s', $field);
                error_log('CNA create_order ERROR: ' . $error_msg);
                return new WP_Error(
                    'missing_field',
                    sprintf(__('Campo requerido faltante: %s', 'cna-subscriptions'), $field),
                    array('status' => 400)
                );
            }
        }

        $product_id = intval($data['product_id']);
        $user_id = intval($data['user_id']);
        $variant = $data['variant']; // {size, qty, frequency, advance_percent}
        $shipping = $data['shipping']; // {department, municipality, district, address, type}

        // Validar que el usuario existe y está autenticado
        $current_user_id = get_current_user_id();
        if ($current_user_id === 0) {
            // Si no hay usuario autenticado, verificar que el user_id sea válido
            $user = get_user_by('id', $user_id);
            if (!$user) {
                return new WP_Error(
                    'invalid_user',
                    __('Usuario no válido', 'cna-subscriptions'),
                    array('status' => 401)
                );
            }
        } else {
            // Si hay usuario autenticado, verificar que coincida con el user_id enviado
            if ($current_user_id !== $user_id) {
                return new WP_Error(
                    'unauthorized',
                    __('No autorizado para crear suscripciones para este usuario', 'cna-subscriptions'),
                    array('status' => 403)
                );
            }
        }

        // Verificar que el producto existe y está publicado
        if (get_post_type($product_id) !== 'cna_product') {
            return new WP_Error(
                'invalid_product',
                __('Producto no válido', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        $product_status = get_post_status($product_id);
        if ($product_status !== 'publish') {
            return new WP_Error(
                'product_not_available',
                __('El producto no está disponible para compra', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        // Verificar duplicados: evitar múltiples suscripciones idénticas activas/pendientes
        global $wpdb;
        $table_prefix = $wpdb->prefix;
        
        $existing_subscription = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table_prefix}cna_subscriptions 
             WHERE user_id = %d 
             AND product_id = %d 
             AND status IN ('pending', 'active')
             AND variant_details = %s
             LIMIT 1",
            $user_id,
            $product_id,
            wp_json_encode($variant, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        ));

        if ($existing_subscription) {
            return new WP_Error(
                'duplicate_subscription',
                __('Ya existe una suscripción activa o pendiente idéntica para este producto', 'cna-subscriptions'),
                array('status' => 409)
            );
        }

        // Validar estructura y tipos de datos de variant
        if (!is_array($variant)) {
            return new WP_Error(
                'invalid_variant',
                __('Datos de variante inválidos', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        $required_variant_fields = array('size', 'qty', 'frequency', 'advance_percent');
        foreach ($required_variant_fields as $field) {
            if (!isset($variant[$field])) {
                return new WP_Error(
                    'missing_variant_field',
                    sprintf(__('Campo requerido faltante en variante: %s', 'cna-subscriptions'), $field),
                    array('status' => 400)
                );
            }
        }

        // Validar tipos y rangos de variant
        $qty = intval($variant['qty']);
        $frequency = intval($variant['frequency']);
        $advance_percent = floatval($variant['advance_percent']);

        if ($qty <= 0 || $qty > 100) {
            return new WP_Error(
                'invalid_quantity',
                __('La cantidad debe estar entre 1 y 100', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        if ($frequency <= 0 || $frequency > 52) {
            return new WP_Error(
                'invalid_frequency',
                __('La frecuencia debe estar entre 1 y 52 semanas', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        if ($advance_percent < 0 || $advance_percent > 100) {
            return new WP_Error(
                'invalid_advance_percent',
                __('El porcentaje de anticipo debe estar entre 0 y 100', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        // Validar estructura de shipping
        if (!is_array($shipping)) {
            return new WP_Error(
                'invalid_shipping',
                __('Datos de envío inválidos', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        if (empty($shipping['type']) || !in_array($shipping['type'], array('home', 'pickup'))) {
            return new WP_Error(
                'invalid_shipping_type',
                __('Tipo de envío inválido', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        // Calcular precios
        error_log('CNA create_order: Calculando totales de la orden');
        $prices = $this->calculate_order_totals($product_id, $variant, $shipping);
        
        if (is_wp_error($prices)) {
            $error_msg = $prices->get_error_message();
            error_log('CNA create_order ERROR cálculo: ' . $error_msg);
            error_log('CNA create_order ERROR cálculo code: ' . $prices->get_error_code());
            
            // Log de error en cálculo
            CNA_Audit_Logger::log(
                CNA_Audit_Logger::EVENT_AMOUNT_CALCULATED,
                array(
                    'subscription_id' => 0,
                    'product_id' => $product_id,
                    'user_id' => $user_id,
                    'error' => $error_msg,
                    'variant' => $variant,
                ),
                CNA_Audit_Logger::SEVERITY_HIGH
            );
            return $prices;
        }
        
        error_log('CNA create_order: Totales calculados: ' . print_r($prices, true));

        // Log de cálculo exitoso
        CNA_Audit_Logger::log(
            CNA_Audit_Logger::EVENT_AMOUNT_CALCULATED,
            array(
                'subscription_id' => 0,
                'product_id' => $product_id,
                'user_id' => $user_id,
                'amount' => $prices['total_with_fee'],
                'net_amount' => $prices['net_amount'],
                'fee_amount' => $prices['fee_amount'],
            ),
            CNA_Audit_Logger::SEVERITY_MEDIUM
        );

        // Crear suscripción en BD con estado 'pending'
        global $wpdb;
        $table_prefix = $wpdb->prefix;

        $subscription_data = array(
            'user_id' => $user_id,
            'product_id' => $product_id,
            'status' => 'pending',
            'shipping_address_json' => wp_json_encode($shipping),
            'variant_details' => wp_json_encode($variant),
            'shipping_cost_unit' => $prices['shipping_unit'],
            'is_auto_renew' => isset($data['auto_renew']) ? (int) $data['auto_renew'] : 1,
        );

        error_log('CNA create_order: Intentando insertar suscripción en BD');
        $result = $wpdb->insert(
            $table_prefix . 'cna_subscriptions',
            $subscription_data,
            array('%d', '%d', '%s', '%s', '%s', '%f', '%d')
        );

        if (!$result) {
            $db_error = $wpdb->last_error;
            error_log('CNA create_order ERROR DB: ' . $db_error);
            error_log('CNA create_order ERROR DB Query: ' . $wpdb->last_query);
            return new WP_Error(
                'db_error',
                __('Error al crear la suscripción', 'cna-subscriptions'),
                array('status' => 500)
            );
        }

        $subscription_id = $wpdb->insert_id;
        error_log('CNA create_order: Suscripción creada con ID: ' . $subscription_id);

        // Log de creación de orden
        CNA_Audit_Logger::log(
            CNA_Audit_Logger::EVENT_ORDER_CREATED,
            array(
                'subscription_id' => $subscription_id,
                'product_id' => $product_id,
                'user_id' => $user_id,
                'amount' => $prices['total_with_fee'],
                'net_amount' => $prices['net_amount'],
                'status' => 'pending',
            ),
            CNA_Audit_Logger::SEVERITY_MEDIUM
        );

        // Crear transacción en Pagadito con tokenización
        $pagadito_client = new CNA_Pagadito_Client();

        $transaction_data = array(
            'amount' => $prices['total_with_fee'],
            'description' => sprintf(
                __('Suscripción #%d - %s', 'cna-subscriptions'),
                $subscription_id,
                get_the_title($product_id)
            ),
            'subscription_id' => $subscription_id,
            'custom_params' => array(
                'subscription_id' => $subscription_id,
                'product_id' => $product_id,
                'user_id' => $user_id,
            ),
        );

        error_log('CNA create_order: Llamando a Pagadito para crear transacción tokenizada');
        error_log('CNA create_order: Transaction data: ' . print_r($transaction_data, true));
        $pagadito_response = $pagadito_client->create_tokenized_transaction($transaction_data);

        if (is_wp_error($pagadito_response)) {
            $error_msg = $pagadito_response->get_error_message();
            error_log('CNA create_order ERROR Pagadito: ' . $error_msg);
            error_log('CNA create_order ERROR Pagadito Code: ' . $pagadito_response->get_error_code());
            $error_details = $pagadito_response->get_error_data();
            if (!empty($error_details['http'])) {
                error_log('CNA create_order ERROR Pagadito HTTP: ' . print_r($error_details['http'], true));
            }
            if (!empty($error_details['response'])) {
                error_log('CNA create_order ERROR Pagadito Response: ' . print_r($error_details['response'], true));
            }
            
            // Marcar suscripción como fallida
            $wpdb->update(
                $table_prefix . 'cna_subscriptions',
                array('status' => 'payment_failed'),
                array('id' => $subscription_id),
                array('%s'),
                array('%d')
            );

            // Log de error al crear transacción
            CNA_Audit_Logger::log(
                CNA_Audit_Logger::EVENT_PAYMENT_FAILED,
                array(
                    'subscription_id' => $subscription_id,
                    'product_id' => $product_id,
                    'user_id' => $user_id,
                    'error' => $error_msg,
                    'stage' => 'transaction_creation',
                ),
                CNA_Audit_Logger::SEVERITY_HIGH
            );

            return $pagadito_response;
        }

        error_log('CNA create_order: Respuesta de Pagadito recibida: ' . print_r($pagadito_response, true));
        $payment_url = CNA_Pagadito_Client::get_payment_url($pagadito_response);

        if (!$payment_url) {
            error_log('CNA create_order ERROR: No se pudo extraer payment_url de la respuesta de Pagadito');
            error_log('CNA create_order ERROR: Respuesta completa: ' . print_r($pagadito_response, true));
            return new WP_Error(
                'no_payment_url',
                __('No se pudo obtener la URL de pago', 'cna-subscriptions'),
                array('status' => 500)
            );
        }

        error_log('CNA create_order: Payment URL obtenida exitosamente: ' . $payment_url);

        // Guardar ID de transacción de Pagadito (si viene en la respuesta)
        if (isset($pagadito_response['transaction_id'])) {
            update_post_meta($product_id, '_cna_pagadito_transaction_' . $subscription_id, $pagadito_response['transaction_id']);
        }

        return rest_ensure_response(array(
            'subscription_id' => $subscription_id,
            'payment_url' => $payment_url,
            'totals' => $prices,
        ));
    }

    /**
     * Endpoint: GET /payment-return
     * Maneja el retorno del usuario después del pago en Pagadito
     */
    public function handle_payment_return($request) {
        $subscription_id = $request->get_param('subscription_id');
        $status = $request->get_param('status');
        $transaction_id = $request->get_param('transaction_id');
        $token = $request->get_param('token');

        error_log('CNA payment_return: Retorno de Pagadito recibido');
        error_log('CNA payment_return: subscription_id=' . $subscription_id . ', status=' . $status);

        if (empty($subscription_id)) {
            // Redirigir a página de error
            wp_safe_redirect(home_url('/finalizar-suscripcion?error=missing_subscription_id'));
            exit;
        }

        global $wpdb;
        $table_prefix = $wpdb->prefix;

        // Obtener suscripción
        $subscription = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_prefix}cna_subscriptions WHERE id = %d",
            intval($subscription_id)
        ));

        if (!$subscription) {
            wp_safe_redirect(home_url('/finalizar-suscripcion?error=subscription_not_found'));
            exit;
        }

        // Si el estado es success/completed, verificar que el webhook ya procesó el pago
        // Si no, esperar a que el webhook lo procese (o procesarlo aquí si es necesario)
        if ($status === 'success' || $status === 'completed') {
            // Verificar si la suscripción ya está activa (procesada por webhook)
            if ($subscription->status === 'active') {
                // Redirigir a página de éxito
                wp_safe_redirect(home_url('/finalizar-suscripcion?subscription_id=' . $subscription_id . '&status=success'));
                exit;
            } else {
                // El webhook aún no ha procesado, mostrar mensaje de espera
                // O intentar verificar el estado directamente con Pagadito
                wp_safe_redirect(home_url('/finalizar-suscripcion?subscription_id=' . $subscription_id . '&status=processing'));
                exit;
            }
        } elseif ($status === 'cancelled' || $status === 'failed') {
            // Redirigir a página de error/cancelación
            wp_safe_redirect(home_url('/finalizar-suscripcion?subscription_id=' . $subscription_id . '&status=cancelled'));
            exit;
        }

        // Estado desconocido, redirigir a checkout
        wp_safe_redirect(home_url('/finalizar-suscripcion?subscription_id=' . $subscription_id));
        exit;
    }

    /**
     * Endpoint: POST /webhook/pagadito
     * Maneja las notificaciones de Pagadito
     */
    public function handle_pagadito_webhook($request) {
        // Validación de IP opcional (si está habilitada)
        $ip_validation_enabled = get_option('cna_pagadito_validate_ip', false);
        
        if ($ip_validation_enabled) {
            $allowed_ips = get_option('cna_pagadito_allowed_ips', '');
            $client_ip = $this->get_client_ip();
            
            if (!empty($allowed_ips)) {
                $allowed_ips_array = array_map('trim', explode("\n", $allowed_ips));
                $allowed_ips_array = array_filter($allowed_ips_array);
                
                if (!empty($allowed_ips_array) && !in_array($client_ip, $allowed_ips_array)) {
                    error_log('CNA webhook: IP no permitida: ' . $client_ip);
                    
                    CNA_Audit_Logger::log(
                        CNA_Audit_Logger::EVENT_WEBHOOK_RECEIVED,
                        array(
                            'subscription_id' => 0,
                            'error' => 'IP no permitida',
                            'ip' => $client_ip,
                            'allowed_ips' => $allowed_ips_array,
                        ),
                        CNA_Audit_Logger::SEVERITY_HIGH
                    );
                    
                    return new WP_Error(
                        'ip_not_allowed',
                        __('IP no permitida', 'cna-subscriptions'),
                        array('status' => 403)
                    );
                }
            }
        }
        
        // Validación básica: HTTPS (excepto en desarrollo local)
        if (!is_ssl() && wp_get_environment_type() !== 'local') {
            CNA_Audit_Logger::log(
                CNA_Audit_Logger::EVENT_WEBHOOK_RECEIVED,
                array(
                    'subscription_id' => 0,
                    'error' => 'Webhook recibido sin HTTPS',
                    'ip' => $this->get_client_ip(),
                ),
                CNA_Audit_Logger::SEVERITY_HIGH
            );
            
            return new WP_Error(
                'insecure_connection',
                __('El webhook debe recibirse por HTTPS', 'cna-subscriptions'),
                array('status' => 403)
            );
        }

        // Validación adicional: Verificar que el webhook tenga estructura mínima esperada
        // Esto ayuda a filtrar requests maliciosos básicos
        $headers = $request->get_headers();
        $user_agent = isset($headers['user_agent']) ? $headers['user_agent'][0] : '';
        
        // Si hay un User-Agent, verificar que no sea un bot común
        if (!empty($user_agent)) {
            $suspicious_agents = array('curl', 'wget', 'python', 'scanner', 'bot');
            $user_agent_lower = strtolower($user_agent);
            foreach ($suspicious_agents as $suspicious) {
                if (strpos($user_agent_lower, $suspicious) !== false && strpos($user_agent_lower, 'pagadito') === false) {
                    CNA_Audit_Logger::log(
                        CNA_Audit_Logger::EVENT_WEBHOOK_RECEIVED,
                        array(
                            'subscription_id' => 0,
                            'error' => 'User-Agent sospechoso: ' . substr($user_agent, 0, 50),
                            'ip' => $this->get_client_ip(),
                        ),
                        CNA_Audit_Logger::SEVERITY_HIGH
                    );
                    
                    // No rechazar, solo loguear (puede ser legítimo)
                }
            }
        }

        $data = $request->get_json_params();
        
        // Si no viene JSON, intentar leer del body raw
        if (empty($data)) {
            $body = $request->get_body();
            $data = json_decode($body, true);
        }

        // Validar que venga información básica
        if (empty($data) || !is_array($data)) {
            return new WP_Error(
                'invalid_webhook',
                __('Datos de webhook inválidos', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        // Extraer información de la transacción
        $transaction_id = isset($data['transaction_id']) ? $data['transaction_id'] : '';
        $status = isset($data['status']) ? strtolower($data['status']) : '';
        $subscription_id = isset($data['custom_params']['subscription_id']) 
            ? intval($data['custom_params']['subscription_id']) 
            : 0;

        if (empty($subscription_id)) {
            return new WP_Error(
                'missing_subscription_id',
                __('ID de suscripción no encontrado', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        global $wpdb;
        $table_prefix = $wpdb->prefix;

        // Obtener suscripción
        $subscription = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_prefix}cna_subscriptions WHERE id = %d",
            $subscription_id
        ));

        if (!$subscription) {
            return new WP_Error(
                'subscription_not_found',
                __('Suscripción no encontrada', 'cna-subscriptions'),
                array('status' => 404)
            );
        }

        // Procesar según el estado
        if ($status === 'completed' || $status === 'approved' || $status === 'success') {
            // Pago exitoso
            return $this->process_successful_payment($subscription, $data);
        } elseif ($status === 'failed' || $status === 'rejected' || $status === 'cancelled') {
            // Pago fallido
            return $this->process_failed_payment($subscription, $data);
        }

        // Estado desconocido, solo loguear
        return rest_ensure_response(array(
            'message' => __('Webhook recibido pero estado no procesado', 'cna-subscriptions'),
            'status' => $status,
        ));
    }

    /**
     * Procesa un pago exitoso
     */
    private function process_successful_payment($subscription, $webhook_data) {
        global $wpdb;
        $table_prefix = $wpdb->prefix;

        // Extraer token si viene en la respuesta
        $token = CNA_Pagadito_Client::extract_token($webhook_data);
        
        // Actualizar suscripción
        $update_data = array(
            'status' => 'active',
        );

        if ($token) {
            // Encriptar token antes de guardarlo
            $encrypted_token = CNA_Token_Encryption::encrypt($token);
            if ($encrypted_token) {
                $update_data['pagadito_token'] = $encrypted_token;
                
                // Log de almacenamiento de token
                CNA_Audit_Logger::log(
                    CNA_Audit_Logger::EVENT_TOKEN_STORED,
                    array(
                        'subscription_id' => $subscription->id,
                        'user_id' => $subscription->user_id,
                        'product_id' => $subscription->product_id,
                    ),
                    CNA_Audit_Logger::SEVERITY_CRITICAL
                );
            }
        }

        $wpdb->update(
            $table_prefix . 'cna_subscriptions',
            $update_data,
            array('id' => $subscription->id),
            array('%s', '%s'),
            array('%d')
        );

        // Log de pago exitoso
        $transaction_id = isset($webhook_data['transaction_id']) ? $webhook_data['transaction_id'] : '';
        CNA_Audit_Logger::log(
            CNA_Audit_Logger::EVENT_PAYMENT_SUCCESS,
            array(
                'subscription_id' => $subscription->id,
                'user_id' => $subscription->user_id,
                'product_id' => $subscription->product_id,
                'transaction_id' => substr($transaction_id, 0, 10) . '...',
                'status' => 'active',
            ),
            CNA_Audit_Logger::SEVERITY_CRITICAL
        );

        // Generar fechas de entrega
        // Decodificar JSON con soporte UTF-8
        $variant_details = json_decode($subscription->variant_details, true, 512, JSON_UNESCAPED_UNICODE);
        if (json_last_error() !== JSON_ERROR_NONE) {
            // Si falla, intentar sin el flag (compatibilidad)
            $variant_details = json_decode($subscription->variant_details, true);
        }
        // Obtener configuración de días del producto
        $delivery_day = intval(get_post_meta($subscription->product_id, '_cna_delivery_day', true));
        $order_cutoff = intval(get_post_meta($subscription->product_id, '_cna_order_cutoff', true));
        
        // Valores por defecto si no están configurados (Jueves=4, Miércoles=2)
        if (empty($delivery_day) && $delivery_day !== '0') {
            $delivery_day = 4; // Jueves
        }
        if (empty($order_cutoff) && $order_cutoff !== '0') {
            $order_cutoff = 2; // Miércoles
        }
        
        $delivery_dates = CNA_Scheduler::calculate_delivery_dates(
            'now',
            intval($variant_details['qty']),
            intval($variant_details['frequency']),
            $delivery_day,
            $order_cutoff
        );

        // Calcular fecha de renovación
        $last_delivery = end($delivery_dates);
        $next_renewal = CNA_Scheduler::calculate_next_renewal_date(
            $last_delivery,
            intval($variant_details['frequency'])
        );

        // Actualizar fecha de renovación
        $wpdb->update(
            $table_prefix . 'cna_subscriptions',
            array('next_renewal_date' => $next_renewal),
            array('id' => $subscription->id),
            array('%s'),
            array('%d')
        );

        // Crear registros de entregas
        $advance_percent = floatval($variant_details['advance_percent']);
        
        // Obtener precio unitario de la variación usando el nuevo helper
        $unit_price = CNA_Product_Helper::get_variation_price($subscription->product_id, strtolower($variant_details['size']));
        if ($unit_price === false) {
            $unit_price = 0;
        }

        // Calcular monto a cobrar por entrega (si no pagó 100%)
        $amount_per_delivery = 0;
        if ($advance_percent < 100) {
            $remaining_percent = (100 - $advance_percent) / 100;
            $amount_per_delivery = ($unit_price * $remaining_percent) / intval($variant_details['qty']);
        }

        foreach ($delivery_dates as $date) {
            $wpdb->insert(
                $table_prefix . 'cna_deliveries',
                array(
                    'subscription_id' => $subscription->id,
                    'scheduled_date' => $date,
                    'payment_status' => ($advance_percent >= 100) ? 'paid' : 'pending',
                    'amount_to_collect' => $amount_per_delivery,
                    'delivery_status' => 'scheduled',
                ),
                array('%d', '%s', '%s', '%f', '%s')
            );
        }

        // Enviar email de confirmación (implementar después)
        // wp_mail(...);

        return rest_ensure_response(array(
            'message' => __('Pago procesado exitosamente', 'cna-subscriptions'),
            'subscription_id' => $subscription->id,
            'deliveries_created' => count($delivery_dates),
        ));
    }

    /**
     * Procesa un pago fallido
     */
    private function process_failed_payment($subscription, $webhook_data) {
        global $wpdb;
        $table_prefix = $wpdb->prefix;

        $wpdb->update(
            $table_prefix . 'cna_subscriptions',
            array('status' => 'payment_failed'),
            array('id' => $subscription->id),
            array('%s'),
            array('%d')
        );

        // Log de pago fallido
        $transaction_id = isset($webhook_data['transaction_id']) ? $webhook_data['transaction_id'] : '';
        CNA_Audit_Logger::log(
            CNA_Audit_Logger::EVENT_PAYMENT_FAILED,
            array(
                'subscription_id' => $subscription->id,
                'user_id' => $subscription->user_id,
                'product_id' => $subscription->product_id,
                'transaction_id' => substr($transaction_id, 0, 10) . '...',
                'status' => 'payment_failed',
            ),
            CNA_Audit_Logger::SEVERITY_HIGH
        );

        // Enviar email de alerta (implementar después)
        // wp_mail(...);

        return rest_ensure_response(array(
            'message' => __('Pago fallido registrado', 'cna-subscriptions'),
            'subscription_id' => $subscription->id,
        ));
    }

    /**
     * Calcula los totales de una orden
     *
     * @param int $product_id
     * @param array $variant
     * @param array $shipping
     * @return array|WP_Error
     */
    private function calculate_order_totals($product_id, $variant, $shipping) {
        // Obtener precio base según variación usando el nuevo helper
        $size = strtolower($variant['size']);
        $unit_price = CNA_Product_Helper::get_variation_price($product_id, $size);

        if ($unit_price === false || $unit_price <= 0) {
            return new WP_Error(
                'invalid_price',
                __('Precio del producto no configurado para esta variación', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        $qty = intval($variant['qty']);
        $advance_percent = floatval($variant['advance_percent']);

        // Subtotal del producto
        $product_subtotal = $unit_price * $qty;

        // Monto de anticipo
        $advance_amount = $product_subtotal * ($advance_percent / 100);

        // Fee anual
        $annual_fee = floatval(get_post_meta($product_id, '_cna_annual_fee', true));

        // Costo de envío
        $shipping_unit = 0;
        if ($shipping['type'] === 'home') {
            // Obtener precio de envío
            $locations_helper = new CNA_Locations_Helper();
            $country = isset($shipping['country']) ? $shipping['country'] : 'El Salvador';
            $zone_id = $locations_helper->find_zone_by_location(
                $shipping['department'],
                $shipping['municipality'],
                $shipping['district'],
                $country
            );

            if ($zone_id) {
                $shipping_prices = get_post_meta($product_id, '_cna_shipping_prices', true);
                if (is_array($shipping_prices) && isset($shipping_prices[$zone_id])) {
                    $shipping_unit = floatval($shipping_prices[$zone_id]);
                }
            }
        } elseif ($shipping['type'] === 'pickup') {
            // Recoger en tienda siempre es $0.00
            $shipping_unit = 0.00;
            
            // Validar que la tienda existe y está activa
            if (isset($shipping['store_id'])) {
                global $wpdb;
                $table_prefix = $wpdb->prefix;
                $store = $wpdb->get_row($wpdb->prepare(
                    "SELECT id FROM {$table_prefix}cna_pickup_stores WHERE id = %d AND is_active = 1",
                    intval($shipping['store_id'])
                ));
                
                if (!$store) {
                    return new WP_Error(
                        'invalid_store',
                        __('La tienda seleccionada no es válida o no está disponible', 'cna-subscriptions'),
                        array('status' => 400)
                    );
                }
            }
        }

        $shipping_total = $shipping_unit * $qty;

        // Neto esperado
        $net_amount = $advance_amount + $shipping_total + $annual_fee;

        // Reverse Fee Calculation
        $pasarela_fee = CNA_Payment_Helper::get_gateway_fee();
        
        // Validar que el fee sea válido (no puede ser >= 100%)
        if ($pasarela_fee >= 1 || $pasarela_fee < 0) {
            return new WP_Error(
                'invalid_gateway_fee',
                __('Configuración de fee de pasarela inválida', 'cna-subscriptions'),
                array('status' => 500)
            );
        }

        // Validar que el monto neto sea positivo
        if ($net_amount <= 0) {
            return new WP_Error(
                'invalid_net_amount',
                __('El monto neto debe ser mayor a cero', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        // Validar límites de monto (máximo $10,000 por transacción)
        if ($net_amount > 10000) {
            return new WP_Error(
                'amount_too_high',
                __('El monto excede el límite máximo permitido', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        $total_with_fee = $net_amount / (1 - $pasarela_fee);
        
        // Validar que el total con fee no exceda límites razonables
        if ($total_with_fee > 15000) {
            return new WP_Error(
                'total_too_high',
                __('El total excede el límite máximo permitido', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        return array(
            'unit_price' => $unit_price,
            'qty' => $qty,
            'product_subtotal' => $product_subtotal,
            'advance_percent' => $advance_percent,
            'advance_amount' => $advance_amount,
            'annual_fee' => $annual_fee,
            'shipping_unit' => $shipping_unit,
            'shipping_total' => $shipping_total,
            'net_amount' => $net_amount,
            'pasarela_fee' => $pasarela_fee,
            'fee_amount' => $total_with_fee - $net_amount,
            'total_with_fee' => $total_with_fee,
        );
    }

    /**
     * Verifica rate limiting básico para endpoints públicos
     * 
     * @param WP_REST_Request $request
     * @return bool|WP_Error
     */
    public function check_rate_limit($request) {
        // Rate limiting básico: máximo 10 requests por minuto por IP
        $ip = $this->get_client_ip();
        $transient_key = 'cna_rate_limit_' . md5($ip);
        $requests = get_transient($transient_key);
        
        if ($requests === false) {
            // Primera request, crear contador
            set_transient($transient_key, 1, 60); // 60 segundos
            return true;
        }
        
        if ($requests >= 10) {
            return new WP_Error(
                'rate_limit_exceeded',
                __('Demasiadas solicitudes. Por favor, intenta de nuevo en un momento.', 'cna-subscriptions'),
                array('status' => 429)
            );
        }
        
        // Incrementar contador
        set_transient($transient_key, $requests + 1, 60);
        return true;
    }

    /**
     * Obtiene la IP real del cliente
     * 
     * @return string
     */
    private function get_client_ip() {
        $ip_keys = array(
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_REAL_IP',
            'HTTP_X_FORWARDED_FOR',
            'REMOTE_ADDR',
        );
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = sanitize_text_field($_SERVER[$key]);
                // Si es X-Forwarded-For, tomar la primera IP
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return '0.0.0.0';
    }

    /**
     * Verifica permisos del usuario para endpoints protegidos
     *
     * @param WP_REST_Request $request
     * @return bool|WP_Error
     */
    public function check_user_permission($request) {
        $user_id = get_current_user_id();
        if ($user_id === 0) {
            return new WP_Error(
                'unauthorized',
                __('Debes estar autenticado para acceder a este recurso', 'cna-subscriptions'),
                array('status' => 401)
            );
        }
        return true;
    }

    /**
     * Endpoint: GET /user/subscriptions
     * Obtiene las suscripciones del usuario actual
     */
    public function get_user_subscriptions($request) {
        $user_id = get_current_user_id();
        
        if ($user_id === 0) {
            return new WP_Error(
                'unauthorized',
                __('Debes estar autenticado', 'cna-subscriptions'),
                array('status' => 401)
            );
        }

        global $wpdb;
        $table_prefix = $wpdb->prefix;

        $subscriptions = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_prefix}cna_subscriptions 
             WHERE user_id = %d 
             ORDER BY created_at DESC",
            $user_id
        ));

        return rest_ensure_response(array(
            'subscriptions' => $subscriptions,
        ));
    }

    /**
     * Endpoint: GET /subscriptions/{id}/deliveries
     * Obtiene las entregas de una suscripción
     */
    public function get_subscription_deliveries($request) {
        $subscription_id = intval($request->get_param('id'));
        $user_id = get_current_user_id();

        if ($user_id === 0) {
            return new WP_Error(
                'unauthorized',
                __('Debes estar autenticado', 'cna-subscriptions'),
                array('status' => 401)
            );
        }

        global $wpdb;
        $table_prefix = $wpdb->prefix;

        // Verificar que la suscripción pertenece al usuario
        $subscription = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_prefix}cna_subscriptions WHERE id = %d AND user_id = %d",
            $subscription_id,
            $user_id
        ));

        if (!$subscription) {
            return new WP_Error(
                'subscription_not_found',
                __('Suscripción no encontrada', 'cna-subscriptions'),
                array('status' => 404)
            );
        }

        $deliveries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_prefix}cna_deliveries 
             WHERE subscription_id = %d 
             ORDER BY scheduled_date ASC",
            $subscription_id
        ));

        return rest_ensure_response(array(
            'deliveries' => $deliveries,
        ));
    }

    /**
     * Endpoint: POST /subscriptions/{id}/toggle-renew
     * Activa o desactiva la auto-renovación de una suscripción
     */
    public function toggle_subscription_renewal($request) {
        $subscription_id = intval($request->get_param('id'));
        $user_id = get_current_user_id();
        $data = $request->get_json_params();
        $enabled = isset($data['enabled']) ? (bool) $data['enabled'] : false;

        if ($user_id === 0) {
            return new WP_Error(
                'unauthorized',
                __('Debes estar autenticado', 'cna-subscriptions'),
                array('status' => 401)
            );
        }

        global $wpdb;
        $table_prefix = $wpdb->prefix;

        // Verificar que la suscripción pertenece al usuario
        $subscription = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_prefix}cna_subscriptions WHERE id = %d AND user_id = %d",
            $subscription_id,
            $user_id
        ));

        if (!$subscription) {
            return new WP_Error(
                'subscription_not_found',
                __('Suscripción no encontrada', 'cna-subscriptions'),
                array('status' => 404)
            );
        }

        // Actualizar auto-renovación
        $wpdb->update(
            $table_prefix . 'cna_subscriptions',
            array('is_auto_renew' => $enabled ? 1 : 0),
            array('id' => $subscription_id),
            array('%d'),
            array('%d')
        );

        // Log de auditoría
        CNA_Audit_Logger::log(
            'subscription_updated',
            array(
                'subscription_id' => $subscription_id,
                'user_id' => $user_id,
                'action' => $enabled ? 'auto_renew_enabled' : 'auto_renew_disabled',
            ),
            CNA_Audit_Logger::SEVERITY_MEDIUM
        );

        return rest_ensure_response(array(
            'success' => true,
            'is_auto_renew' => $enabled,
        ));
    }

    /**
     * Endpoint: GET /locations
     * Obtiene los datos geográficos de El Salvador
     */
    public function get_locations_data($request) {
        $locations_helper = new CNA_Locations_Helper();
        $all_locations = $locations_helper->get_all_locations();

        // Transformar estructura para facilitar uso en frontend
        $departments = array();
        $municipalities = array();
        $districts = array();

        if (isset($all_locations['El Salvador'])) {
            foreach ($all_locations['El Salvador'] as $dept => $munis) {
                $departments[] = $dept;
                $municipalities[$dept] = array();
                
                foreach ($munis as $muni => $districts_list) {
                    $municipalities[$dept][] = $muni;
                    $districts[$dept][$muni] = $districts_list;
                }
            }
        }

        return rest_ensure_response(array(
            'departments' => $departments,
            'municipalities' => $municipalities,
            'districts' => $districts,
        ));
    }

    /**
     * Endpoint: POST /register
     * Registra un nuevo usuario
     */
    public function register_user($request) {
        $data = $request->get_json_params();

        // Validar datos requeridos
        if (empty($data['email']) || empty($data['password'])) {
            return new WP_Error(
                'missing_fields',
                __('El correo electrónico y la contraseña son requeridos', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        $email = sanitize_email($data['email']);
        $password = $data['password'];
        $first_name = isset($data['first_name']) ? sanitize_text_field($data['first_name']) : '';
        $last_name = isset($data['last_name']) ? sanitize_text_field($data['last_name']) : '';

        // Validar email
        if (!is_email($email)) {
            return new WP_Error(
                'invalid_email',
                __('El correo electrónico no es válido', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        // Validar contraseña
        if (strlen($password) < 6) {
            return new WP_Error(
                'weak_password',
                __('La contraseña debe tener al menos 6 caracteres', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        // Verificar si el email ya existe
        if (email_exists($email)) {
            return new WP_Error(
                'email_exists',
                __('Este correo electrónico ya está registrado', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        // Crear usuario
        $username = sanitize_user($email, true);
        // Si el username ya existe, agregar un número
        $original_username = $username;
        $counter = 1;
        while (username_exists($username)) {
            $username = $original_username . $counter;
            $counter++;
        }

        $user_id = wp_create_user($username, $password, $email);

        if (is_wp_error($user_id)) {
            return new WP_Error(
                'registration_failed',
                $user_id->get_error_message(),
                array('status' => 400)
            );
        }

        // Actualizar metadatos del usuario
        if ($first_name) {
            update_user_meta($user_id, 'first_name', $first_name);
        }
        if ($last_name) {
            update_user_meta($user_id, 'last_name', $last_name);
        }

        // Establecer nombre para mostrar
        $display_name = trim($first_name . ' ' . $last_name);
        if (empty($display_name)) {
            $display_name = $username;
        }
        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $display_name,
        ));

        // Log de auditoría
        CNA_Audit_Logger::log(
            'user_registered',
            array(
                'user_id' => $user_id,
                'email' => $email,
                'ip' => $this->get_client_ip(),
            ),
            CNA_Audit_Logger::SEVERITY_MEDIUM
        );

        return rest_ensure_response(array(
            'success' => true,
            'user_id' => $user_id,
            'message' => __('Usuario registrado exitosamente', 'cna-subscriptions'),
        ));
    }

    /**
     * Endpoint: POST /login
     * Inicia sesión de usuario
     */
    public function login_user($request) {
        $data = $request->get_json_params();

        // Validar datos requeridos
        if (empty($data['email']) || empty($data['password'])) {
            return new WP_Error(
                'missing_fields',
                __('El correo electrónico y la contraseña son requeridos', 'cna-subscriptions'),
                array('status' => 400)
            );
        }

        $email = sanitize_email($data['email']);
        $password = $data['password'];

        // Obtener usuario por email
        $user = get_user_by('email', $email);
        if (!$user) {
            return new WP_Error(
                'invalid_credentials',
                __('Correo electrónico o contraseña incorrectos', 'cna-subscriptions'),
                array('status' => 401)
            );
        }

        // Verificar contraseña
        if (!wp_check_password($password, $user->user_pass, $user->ID)) {
            // Log de intento fallido
            CNA_Audit_Logger::log(
                'login_failed',
                array(
                    'user_id' => $user->ID,
                    'email' => $email,
                    'ip' => $this->get_client_ip(),
                    'reason' => 'invalid_password',
                ),
                CNA_Audit_Logger::SEVERITY_MEDIUM
            );

            return new WP_Error(
                'invalid_credentials',
                __('Correo electrónico o contraseña incorrectos', 'cna-subscriptions'),
                array('status' => 401)
            );
        }

        // Establecer cookies de autenticación
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID, isset($data['remember']) ? $data['remember'] : false);

        // Log de auditoría
        CNA_Audit_Logger::log(
            'user_logged_in',
            array(
                'user_id' => $user->ID,
                'email' => $email,
                'ip' => $this->get_client_ip(),
            ),
            CNA_Audit_Logger::SEVERITY_MEDIUM
        );

        return rest_ensure_response(array(
            'success' => true,
            'user_id' => $user->ID,
            'user' => array(
                'id' => $user->ID,
                'email' => $user->user_email,
                'display_name' => $user->display_name,
            ),
            'message' => __('Sesión iniciada exitosamente', 'cna-subscriptions'),
        ));
    }
}
